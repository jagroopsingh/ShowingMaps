package com.apps.gill.showingmaps.utils;

/**
 * Created by gill on 22-02-2016.
 */
public interface AppConstant {
    public static  String serverKey="AIzaSyDHMOOh_GXANAm3TCJeG33o-QUp3D6BevE";
}
